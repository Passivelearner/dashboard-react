import { Drawer, Typography } from "@mui/material";
import { makeStyles } from "@mui/styles"
import React from 'react';
import CONTENT_STRINGS from "../config/contentStrings";
import { Outlet } from "react-router-dom";
import Searchbar from "./Searchbar";
import MiniVariantDrawer from "./MiniVariantDrawer";

const drawerWidth = 240

const useStyles = makeStyles({
    mainPage : {
        background : '#f9f9f9',
        width : '100%',
        marginLeft : 5
    },
    drawer : {
        width : drawerWidth
    },
    drawerPaper : {
        width : drawerWidth
    },
    root : {
        display : 'flex'
    }
})

export default function Layout(){
    const classes = useStyles()

    return <React.Fragment>
            <div className={classes.root}>
                {/* Side Nav */}
                    <MiniVariantDrawer/>
                <div className={classes.mainPage}>
                    <Searchbar/>
                    <Outlet/>
                </div>
            </div>
        </React.Fragment>
}