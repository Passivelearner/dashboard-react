import { Card, CardContent, CardHeader, Container,Typography } from "@mui/material"
import MoreVertIcon from '@mui/icons-material/MoreVert';
import IconButton from '@mui/material/IconButton';
import Avatar from '@mui/material/Avatar';
import CONTENT_STRINGS from "../config/contentStrings";
import textColorChanger from "../helper/textColorChanger.helper";
import MenuOptions from "./MenuOptions";
import ViewInArOutlinedIcon from '@mui/icons-material/ViewInArOutlined';


function Order(){

    const perc = "-13.24%"

    return <Card sx={{height : '100%'}}>
            <CardHeader
                avatar={<ViewInArOutlinedIcon color="primary"/>}
                action={<MenuOptions/>}
                titleTypographyProps={{variant:'body1'}}
            >
            </CardHeader>
            <CardContent>
                <Container>
                    <Typography variant="body1">
                        {CONTENT_STRINGS.BODY.ORDER_LABEL}
                    </Typography>
                    <Typography variant="h5">
                        $1,286
                    </Typography>
                    <Typography variant="body2" sx={{color : textColorChanger(perc)}}>
                        {perc}
                    </Typography>
                </Container>
            </CardContent>
        </Card>
}

export default Order