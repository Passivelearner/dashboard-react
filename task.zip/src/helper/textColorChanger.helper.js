function textColorChanger(str){
    return str.includes('+') ? '#71DD38' : '#FF3933'
}


export default textColorChanger