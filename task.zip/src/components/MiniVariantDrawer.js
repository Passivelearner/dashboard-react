import { Typography } from "@mui/material";
import { makeStyles } from "@mui/styles"
import React from 'react';
import CONTENT_STRINGS from "../config/contentStrings";
import { Outlet } from "react-router-dom";
import Searchbar from "./Searchbar";
import Divider from '@mui/material/Divider';
import Drawer from '@mui/material/Drawer';
import IconButton from '@mui/material/IconButton';
import InboxIcon from '@mui/icons-material/MoveToInbox';
import List from '@mui/material/List';
import ListItem from '@mui/material/ListItem';
import ListItemButton from '@mui/material/ListItemButton';
import ListItemIcon from '@mui/material/ListItemIcon';
import ListItemText from '@mui/material/ListItemText';
import MailIcon from '@mui/icons-material/Mail';
import MenuIcon from '@mui/icons-material/Menu';
import Toolbar from '@mui/material/Toolbar';
import ChevronLeftIcon from '@mui/icons-material/ChevronLeft';
import { styled, useTheme } from '@mui/material/styles';
import HomeOutlinedIcon from '@mui/icons-material/HomeOutlined';
import SpaceDashboardOutlinedIcon from '@mui/icons-material/SpaceDashboardOutlined';
import StorefrontOutlinedIcon from '@mui/icons-material/StorefrontOutlined';
import EmailOutlinedIcon from '@mui/icons-material/EmailOutlined';
import QuestionAnswerOutlinedIcon from '@mui/icons-material/QuestionAnswerOutlined';
import CalendarMonthOutlinedIcon from '@mui/icons-material/CalendarMonthOutlined';
import GridOnOutlinedIcon from '@mui/icons-material/GridOnOutlined';
import ShoppingCartOutlinedIcon from '@mui/icons-material/ShoppingCartOutlined';
import AutoStoriesOutlinedIcon from '@mui/icons-material/AutoStoriesOutlined';
import TimeToLeaveOutlinedIcon from '@mui/icons-material/TimeToLeaveOutlined';
import ReceiptLongOutlinedIcon from '@mui/icons-material/ReceiptLongOutlined';
import Person2OutlinedIcon from '@mui/icons-material/Person2Outlined';
import GppGoodOutlinedIcon from '@mui/icons-material/GppGoodOutlined';
import WebAssetOutlinedIcon from '@mui/icons-material/WebAssetOutlined';


const drawerWidth = 240

const useStyles = makeStyles({
    mainPage : {
        background : '#f9f9f9',
        width : '100%',
        marginLeft : 5
    },
    drawer : {
        width : drawerWidth
    },
    drawerPaper : {
        width : drawerWidth
    },
    root : {
        display : 'flex'
    }
})

const DrawerHeader = styled('div')(({ theme }) => ({
    display: 'flex',
    alignItems: 'center',
    padding: theme.spacing(0, 1),
    // necessary for content to be below app bar
    ...theme.mixins.toolbar,
    justifyContent: 'flex-end',
  }));


const firstIcons = [
    { 
        component : <HomeOutlinedIcon/>,
        name : "Dashboards"        
    },
    { component : <SpaceDashboardOutlinedIcon/>,
        name : "Layouts" 
    },
    {
        component : <StorefrontOutlinedIcon/>,
        name : "Front Pages"
    }
]

const secondIcons = [
    { component : <EmailOutlinedIcon/>, name : "Email"},
    { component : <QuestionAnswerOutlinedIcon/>, name : "Chat"},
    { component : <CalendarMonthOutlinedIcon/>, name : "Calendar"},
    { component : <GridOnOutlinedIcon/>, name : "Kanban"},
    { component : <ShoppingCartOutlinedIcon/>, name : "eCommerce"},
    { component : <AutoStoriesOutlinedIcon/>, name : "Academy"},
    { component : <ReceiptLongOutlinedIcon/>, name : "Invoice"},
    { component : <Person2OutlinedIcon/>, name : "Users"},
    { component : <GppGoodOutlinedIcon/>, name : "Roles & Permissions"},
    { component : <WebAssetOutlinedIcon/>, name : "Pages"}, 
]

export default function MiniVariantDrawer(){
    const classes = useStyles()

    return <Drawer
                className={classes.drawer}
                variant="permanent"
                anchor="left"
                classes={{
                    paper : classes.drawerPaper
                }}
                open={true}
                onFocus={() => console.log('hovered')}
            >
                <DrawerHeader>
                    <IconButton >
                        <ChevronLeftIcon />
                    </IconButton>
                </DrawerHeader>
                <div>
                
                    <List>
                        {firstIcons.map((component, index) => (
                        <ListItem key={index} disablePadding>
                            <ListItemButton>
                            <ListItemIcon>
                                {component.component}
                            </ListItemIcon>
                            <ListItemText primary={component.name} />
                            </ListItemButton>
                        </ListItem>
                        ))}
                    </List>
                    <Divider />
                    <List>
                        {secondIcons.map((component, index) => (
                        <ListItem key={index} disablePadding>
                            <ListItemButton>
                            <ListItemIcon>
                                {component.component}
                            </ListItemIcon>
                            <ListItemText primary={component.name} />
                            </ListItemButton>
                        </ListItem>
                        ))}
                    </List>
                </div>
            </Drawer>

}