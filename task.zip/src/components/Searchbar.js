import { Card, CardContent, Container, TextField } from "@mui/material"
import { makeStyles, styled  } from "@mui/styles"
import CONTENT_STRINGS from "../config/contentStrings"
import SearchIcon from '@mui/icons-material/Search';


import DarkModeButton from "./DarkModeButton";
import LanguageMenu from "./LanguageMenu";
import ProfileMenu from "./ProfileMenu";
import NotificationMenu from "./NotificationMenu";
import ShortcutMenu from "./ShortcutMenu";

const useStyles = makeStyles({
    root : {
        position : 'sticky', 
        top : 0,
        zIndex : 1100
    }
})


function Searchbar(){
    const classes = useStyles()
    


    return <Card elevation={2} className={classes.root}> 
        <CardContent>
            <Container sx={{display : 'flex', alignItems: 'flex-end', placeItems : 'center', height : '40px'}}>
                <TextField 
                    fullWidth
                    variant="standard"
                    InputProps={{
                        startAdornment: <SearchIcon />, 
                        disableUnderline: true, 
                    }}
                    placeholder={CONTENT_STRINGS.BODY.SEARCH_BAR_HINT}
                />
                <ShortcutMenu/>
                <LanguageMenu/>
                <DarkModeButton/>
                <NotificationMenu/>
                <ProfileMenu/>
                
            </Container>
        </CardContent>
    </Card>
}

export default Searchbar